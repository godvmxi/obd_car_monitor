/****************************************************************************
** Meta object code from reading C++ file 'dialogsetcom.h'
**
** Created: Mon Jun 4 20:18:54 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../IAP/dialogsetcom.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialogsetcom.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_DialogSetCom[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      26,   14,   13,   13, 0x05,

 // slots: signature, parameters, type, tag, flags
      60,   13,   13,   13, 0x08,
      90,   13,   13,   13, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_DialogSetCom[] = {
    "DialogSetCom\0\0setting,com\0"
    "emitComInfo(PortSettings,QString)\0"
    "on_pushButtonCancel_clicked()\0"
    "on_pushButtonSet_clicked()\0"
};

const QMetaObject DialogSetCom::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_DialogSetCom,
      qt_meta_data_DialogSetCom, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &DialogSetCom::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *DialogSetCom::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *DialogSetCom::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DialogSetCom))
        return static_cast<void*>(const_cast< DialogSetCom*>(this));
    return QDialog::qt_metacast(_clname);
}

int DialogSetCom::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: emitComInfo((*reinterpret_cast< PortSettings(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 1: on_pushButtonCancel_clicked(); break;
        case 2: on_pushButtonSet_clicked(); break;
        default: ;
        }
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void DialogSetCom::emitComInfo(PortSettings _t1, QString _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
