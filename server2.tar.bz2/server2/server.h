#ifndef SERVER_H
  #define SERVER_H
  //********* Head File *****************************************
  #include <stdio.h>
  #include <string.h>
  #include <unistd.h>
  #include <sys/types.h>
  #include <sys/socket.h>
  #include <sys/stat.h>
  #include <stdlib.h>
  #include <netinet/in.h>
  #include <arpa/inet.h>
  #include <fcntl.h>    // open
  
  #include <pthread.h>
  
  typedef unsigned char uchar;
  typedef unsigned short ushort; 
  
  #define MAX_THREAD_NUM 100

  //********* Application Info **********************************
  #define MAX_APP_LEN 1024000
  #define MAX_DATA_LEN 512      // MAX of App Package
  #define HARD_VARTION 1        // hard Vartion
  #define SOFT_VARTION 7        // soft Vartion
  const char* APP_NAME = "doc.dat";// File of App
  struct APP_INFO_BLOCK         // App Info
  {
     int app_size;              // App Data Size
     ushort app_CRC;            // App Data CRC16
     int package_num;           // App Data Package Number
     int last_package;          // App Last Package Size
  };//app_info_block;

  //int getAPP_INFO_BLOCK(struct APP_INFO_BLOCK*);
  //int getAppPackage(uchar*,int);
  //********* TCP Socket ****************************************
  #define TCP_PORT 9000         // TCP Socket Port
  #define BACKLOG 3             // TCP Accept Number  
  #define HEAD_NUM 4
  #define MESSAGE_TYPE 18
  struct AUTH_REQUEST_BLOCK
  {
     uchar head[2];             // "##"
     ushort CRC;                // CRC16
     short msg_type;            // Message Type
     uchar hard_var;            // Hard Vartion
     uchar soft_var;            // Soft Vartion
     unsigned int IMEI_HIGH;            // IMEI
     
     unsigned int IMEI_LOW;             // IMEI
  };//auth_req_block;

  struct AUTH_BACK_BLOCK
  {
     uchar head[2];             // "##"
     ushort CRC;                // CRC16
     short msg_type;           // Message Type
     uchar hard_var;            // Hard Vartion
     uchar soft_var;            // Soft Vartion
     ushort package_num;
     ushort app_CRC;
     unsigned int app_size;
  };//auth_back_block;

  struct DATA_BACK_BLOCK
  {
     uchar head[2];             // "##"
     ushort CRC;                // CRC
     short package_index;      // Message Type 
     uchar hard_var;             // Hard Vartion
     uchar soft_var;             // Soft Vartion
     ushort data_CRC;
     ushort data_size;
     uchar un_use[4];
     uchar data[MAX_DATA_LEN];
  };//data_back_block;

  int getAPP_INFO_BLOCK(struct APP_INFO_BLOCK* app_info_block);
  int getAppPackage(uchar* buff,int package_id,struct APP_INFO_BLOCK app_info_block);
  int authAUTH_REQUEST_BLOCK(struct AUTH_REQUEST_BLOCK auth_back_block);
  int authDATA_REQUEST_BLOCK(struct AUTH_REQUEST_BLOCK auth_back_block,struct APP_INFO_BLOCK app_info_block);
  int setAUTH_BACK_BLOCK(struct AUTH_BACK_BLOCK *auth_back_block,struct APP_INFO_BLOCK app_info_block);
  int setDATA_BACK_BLOCK(struct DATA_BACK_BLOCK *data_back_block,int package_id,struct APP_INFO_BLOCK app_info_block); 
  //********* CRC16 ***********************************************
  
  ushort getCRC16(uchar* data, int dataLen);
  //********* CRC16 ***********************************************
#endif
