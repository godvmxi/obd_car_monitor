#include "server.h"
#include "signal.h"


ushort getCRC16(unsigned char* data, int dataLen)
{
    ushort crc;
    uchar  da;
    int len = dataLen;
    const ushort crc_ta[256]={
                0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
                0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
                0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
                0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
                0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
                0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
                0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
                0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
                0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
                0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
                0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
                0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
                0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
                0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
                0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
                0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
                0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
                0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
                0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
                0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
                0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
                0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
                0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
                0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
                0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
                0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
                0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
                0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
                0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
                0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
                0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
                0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0
     };
     printf("In getCRC16()==> CRC length is %d\n",dataLen);
     crc=0;
     while(len--!=0) 
     {
         da=(uchar) (crc/256); 
         crc<<=8;
         crc^=crc_ta[da^*data];
         data++;
     }
     putchar('\n');
     return(crc);

}

int getAPP_INFO_BLOCK(struct APP_INFO_BLOCK* app_info_block)
{
   struct stat f_stat;
   int app_size;
   int package_num;
   int fd;
   int resize;
   uchar buff[MAX_APP_LEN];
   //********* get App Size **********************************
   if( stat( APP_NAME, &f_stat ) == -1 )
   {
     printf("==> Get App Size Error...\n");
     return -1;
   }
   app_size = f_stat.st_size;
   app_info_block-> app_size = app_size ;
   printf("==> App size is %d...\n",app_info_block-> app_size);

   //********* get App Size **********************************
   package_num = app_size / MAX_DATA_LEN;
   if(package_num*MAX_DATA_LEN < app_size)
     package_num ++;
   app_info_block-> package_num = package_num;
   printf("==> Package Num is %d...\n",app_info_block-> package_num);

   //********* get Last Package Size *************************
   app_info_block-> last_package = app_size - ((package_num-1)*MAX_DATA_LEN);
   printf("==> Last Package Size is %d...\n",app_info_block-> last_package);

   //********* get App CRC16 *********************************
   if((fd=open(APP_NAME,O_RDONLY)) < 0)
   {
      perror("Open Error ...");
      return -1;
   }
   if((resize = read(fd,buff,app_size)) < 0)
                                // read data
   {
      perror("Read Error...");
      return -1;
   }
   if(resize != app_size)
   {
      printf("==> Read Data Num is not match...");
      return -1;
   }
 
   app_info_block-> app_CRC = getCRC16(buff, resize);
   printf("==> App Data CRC16 is 0x%x...\n",app_info_block-> app_CRC);
   if(close(fd) < 0)            // Close File
   {
      perror("Close Error ...");
      return -1;
   }
   return 1;
}

int getAppPackage(uchar* buff,int package_id,struct APP_INFO_BLOCK app_info_block)
{
   int fd;   
   int resize = 0;
   int repoint = 0;
   if((fd=open(APP_NAME,O_RDONLY)) < 0)
   {
      perror("Open Error ...");
      return -1;
   }
   repoint = lseek(fd,(package_id-1)*MAX_DATA_LEN,SEEK_SET);
                                // set point
   if(repoint != (package_id-1)*MAX_DATA_LEN)
   {
      printf("==> File Point is %d",repoint);
      return -1;
   }
   if((resize = read(fd,buff,MAX_DATA_LEN)) < 0)
                                // read data
   {
      perror("Read Error...");
      return -1;
   }
   if((package_id<app_info_block.package_num)&&(resize != MAX_DATA_LEN))
   {
      printf("==> Package %d Read Data Num is not match...\n",package_id);
   }
   else if((package_id==app_info_block.package_num)&&(resize != app_info_block.last_package)) 
   {
      printf("==> Package %d Read Data Num is not match...\n",package_id);
   } 
   
   if(close(fd) < 0)            // close file
   {
      perror("Close Error ...");
      return -1;
   }
}

int authAUTH_REQUEST_BLOCK(struct AUTH_REQUEST_BLOCK auth_req_block)
{
   ushort crc;
   printf("==> Auth auth_back_block From Client...\n");
   printf("==>    head is %c%c\n",auth_req_block.head[0],
   auth_req_block.head[1]);

   printf("==>    Meg_Type is %d\n",auth_req_block.msg_type);
   printf("==>    Hard Vartion is %d\n",auth_req_block.hard_var);
   printf("==>    Soft Vartion is %d\n",auth_req_block.soft_var);
   printf("==>    IMEI is %d%d\n",auth_req_block.IMEI_HIGH,auth_req_block.IMEI_LOW);
   printf("==>    Recive CRC is 0x%X\n",auth_req_block.CRC);
   crc = getCRC16((unsigned char *)&auth_req_block + HEAD_NUM,sizeof(struct AUTH_REQUEST_BLOCK)-HEAD_NUM);
   printf("==>    Local CRC is 0x%X\n",crc);
   if(auth_req_block.CRC != crc)
   {
      printf("==> auth_req_block CRC is not match..%16X%6X\n",crc,auth_req_block.CRC);
      // return -1;
   }
   else
   {
      printf("==> auth_req_block CRC is match..\n");
   }
   if(auth_req_block.hard_var != HARD_VARTION)
   {
      printf("==> the hardware vartion is not match..%3X %3X\n",HARD_VARTION,auth_req_block.hard_var);
      return -1;
   }
   if(auth_req_block.soft_var == SOFT_VARTION)
   {
      printf("==> the software vartion is not match..%3X %3X\n",SOFT_VARTION,auth_req_block.soft_var);
      return -1;
   }
   return 1;
}

int authDATA_REQUEST_BLOCK(struct AUTH_REQUEST_BLOCK auth_req_block,struct APP_INFO_BLOCK app_info_block)
{
   ushort crc;
   printf("==> Auth auth_req_block From Client...\n");
   printf("==>    head is %c%c\n",auth_req_block.head[0],
         auth_req_block.head[1]);
   //printf("==>    CRC is 0x%x\n",auth_req_block.CRC);
   printf("==>    Package ID is %d\n",auth_req_block.msg_type);
   if(auth_req_block.msg_type<=0 || auth_req_block.msg_type>app_info_block.package_num)
   {
      printf("==> the package id not match...\n");
      return -1;
   }
   printf("==>    Hard Vartion is %d\n",auth_req_block.hard_var);
   printf("==>    Soft Vartion is %d\n",auth_req_block.soft_var);
   printf("==>    IMEI is %d%d\n",auth_req_block.IMEI_HIGH,auth_req_block.IMEI_LOW);
   printf("==>    Recive CRC is 0x%X\n",auth_req_block.CRC);
   crc = getCRC16((unsigned char *)&auth_req_block + HEAD_NUM,sizeof(struct AUTH_REQUEST_BLOCK)-HEAD_NUM);
   printf("==>    Local CRC is 0x%X\n",crc);
   if(auth_req_block.CRC != crc)
   {  
      printf("==> auth_req_block CRC is not match..\n");
      //return -1;
   }
   else
   {
      printf("==> auth_req_block CRC is match..\n");
   }
   return auth_req_block.msg_type;
}


int setAUTH_BACK_BLOCK(struct AUTH_BACK_BLOCK *auth_back_block,struct APP_INFO_BLOCK app_info_block)
{
   //int i;
   //uchar *p;
   auth_back_block->head[0] = '#';
   auth_back_block->head[1] = '#';
   auth_back_block->msg_type = MESSAGE_TYPE;
   auth_back_block->hard_var = HARD_VARTION;
   auth_back_block->soft_var = SOFT_VARTION;
   
   auth_back_block->package_num = app_info_block.package_num;
   auth_back_block->app_CRC = app_info_block.app_CRC;
   auth_back_block->app_size = app_info_block.app_size;
   auth_back_block->CRC = getCRC16(((uchar *)auth_back_block)+HEAD_NUM,sizeof(struct AUTH_BACK_BLOCK)-HEAD_NUM);
   printf("==> auth_back_block CRC is 0x%X\n",auth_back_block->CRC);
   //p = (uchar *)auth_back_block;
   //for(i=4;i<sizeof(struct AUTH_BACK_BLOCK);i++)
   //  printf("%X:",*(p+i));
   //putchar('\n');
   //printf("================================\n");
   return 1;
}

int setDATA_BACK_BLOCK(struct DATA_BACK_BLOCK *data_back_block,int package_id,struct APP_INFO_BLOCK app_info_block)
{
    int i;
    printf("==> Init DATA_BACK_BLOCK Struct\n");
    int data_size = MAX_DATA_LEN;
    if(package_id == app_info_block.package_num)
       data_size = app_info_block.last_package;
    bzero(data_back_block,sizeof(struct DATA_BACK_BLOCK)); 
    data_back_block->head[0] = '#';
    data_back_block->head[1] = '#';
    data_back_block->package_index = package_id;
    data_back_block->hard_var = HARD_VARTION;
    data_back_block->soft_var = SOFT_VARTION;
    data_back_block->data_size = data_size;
    data_back_block->un_use[0] = '*';
    data_back_block->un_use[1] = '*';
    data_back_block->un_use[2] = '*';
    data_back_block->un_use[3] = '*';
    printf("  ==> data_back_block data_size is %d\n",data_back_block->data_size);
    //data_back_block.CRC = 0x9090;
    
    if(getAppPackage(data_back_block->data,package_id,app_info_block)==-1)
    {
       printf("==> get AppPackage %d error ...\n",package_id);
       return -1;
    }
    data_back_block->data_CRC = getCRC16(data_back_block->data,data_size); 
    printf("  ==> data_back_block data CRC is 0x%x\n",data_back_block->data_CRC);
    data_back_block->CRC = getCRC16(((uchar *)data_back_block)+HEAD_NUM,12);
    printf("  ==> data_back_block CRC is 0x%x\n",data_back_block->CRC);
    printf("=======head of data_back_block:");
    for(i=0;i<10;i++)
       printf("%X:",*((uchar *)data_back_block+i));
    putchar('\n');
    return 1;
}


void *thread_socket(void *fd)
{
   //pthread_t tid;
   int connectfd = *(int *)fd;
   struct APP_INFO_BLOCK app_info_block;
   struct AUTH_REQUEST_BLOCK auth_req_block;
   struct AUTH_BACK_BLOCK auth_back_block;
   struct DATA_BACK_BLOCK data_back_block;
   int recvlen,sendlen;                         // recv/send data length
   int i;
   int package_id = 0;
   unsigned     char *p = (unsigned char *)&auth_req_block;
   printf("==> New process PID is %d\n",getpid());
   if(getAPP_INFO_BLOCK(&app_info_block)==-1)
   {
      printf("==> Get APP_INFO_BLOCK Error ...");
      goto exit_thread;
   }
   
   //********* TCP Socket Receive AUTH_REQUEST_BLOCK **********
   recvlen = recv(connectfd,&auth_req_block,
       sizeof(struct AUTH_REQUEST_BLOCK),0);
                                        // receive data
   printf("==> TCP receive length :%d\n",recvlen);
   for(i = 0;i<recvlen;i++)
   {
       printf("%3X",p[i]);
   }
   printf("\n==============================\n");
   if(recvlen == -1)
   {
       perror("TCP Socket recv ERROR.");
       //return 0;
       goto exit_thread;
   }
   else if(recvlen != sizeof(struct AUTH_REQUEST_BLOCK))
   {
       printf("==> TCP Socket recv data not mactch...\n");
       printf("==>    Receive : %d;Should be  %d\n",recvlen,sizeof(struct AUTH_REQUEST_BLOCK));
       goto exit_thread;
       
   }
   else
   {
       printf("==> TCP Socket recv data mactch...\n");
   }
   //********* auth AUTH_REQUEST_BLOCK is OK or NOT **********
   if(authAUTH_REQUEST_BLOCK(auth_req_block) == -1)
   {
       printf("==> auth AUTH_REQUEST_BLOCK ERROR...\n");
       goto exit_thread;
   }
   //********* Init AUTH_BACK_BLOCK Struct *******************
   if(setAUTH_BACK_BLOCK(&auth_back_block,app_info_block) == -1)
   {
       printf("==> set AUTH_BACK_BLOCK ERROR...\n");
       goto exit_thread;
   }
   //********* TCP Socket Send AUTH_BACK_BLOCK ***************
   sendlen = send(connectfd,&auth_back_block,sizeof(struct AUTH_BACK_BLOCK),0);
   if(sendlen == -1)
   {
       perror("TCP Socket send ERROR.");
       goto exit_thread;
   }
   else if(sendlen != sizeof(struct AUTH_BACK_BLOCK))
   {
      printf("==> TCP Socket send AUTH_BACK_BLOCK not macth...\n");
      goto exit_thread;
   }
   else
   {
      printf("==> TCP Socket send AUTH_BACK_BLOCK OK...\n");
   }
      
   //********* TCP Socket Send App Data **********************
   while(package_id < app_info_block.package_num)
   {
      printf("==> waiting for package ask...\n");
      recvlen = recv(connectfd,&auth_req_block,
            sizeof(struct AUTH_REQUEST_BLOCK),0);
      if(recvlen == -1)
      {
         perror("TCP Socket recv ERROR.");
         goto exit_thread;
      }
      else if(recvlen != sizeof(struct AUTH_REQUEST_BLOCK))
      {
         //printf("==> TCP Socket recv AUTH_REQUEST_BLOCK not mactch...\n");
          printf("==> TCP Socket recv data not mactch...\n");
          printf("==>    Receive:%d, should be %d\n",recvlen,sizeof(struct AUTH_REQUEST_BLOCK));
          printf("==> continue waiting for package ask...\n");
          continue;
      }
      else
      {
          printf("==> TCP Socket recv AUTH_REQUEST_BLOCK mactch...\n");
          
      }
      //********* auth DATA_REQUEST_BLOCK is OK or NOT **********
      if((package_id=authDATA_REQUEST_BLOCK(auth_req_block,app_info_block)) == -1)
      {
         printf("==> auth DATA_REQUEST_BLOCK error...\n");
         printf("==> continue waiting for package ask...\n");
         continue;
      }
      printf("==> Client Ask Package %d...\n",package_id);
      //********* TCP Socket Send DATA_BACK_BLOCK ***************
      if(setDATA_BACK_BLOCK(&data_back_block,package_id,app_info_block)==-1)
      {
         printf("==> Init DATA_BACK_BLOCK struct error ...\n");
         goto exit_thread;
      }
      //********* TCP Socket Send DATA_BACK_BLOCK ***************
      sendlen = send(connectfd,&data_back_block,sizeof(struct DATA_BACK_BLOCK),0);
      if(sendlen == -1)
      {
         perror("TCP Socket send DATA_BACK_BLOCK ERROR.");
         goto exit_thread;
      }
      else if(sendlen != sizeof(struct DATA_BACK_BLOCK))
      {
         printf("==> TCP Socket send DATA_BACK_BLOCK not mactch...\n");
         printf("==> continue waiting for package ask...\n");
         continue;
      }
      else
      {
      	 printf("==> TCP Socket send DATA_BACK_BLOCK OK...\n");
      }
   }
   if(package_id == app_info_block.package_num)
   {
      printf("==> App Data Trans is OK...\n");
   }
   exit_thread:
   close(connectfd);
   printf("==> TCP Socket %d is Closed...\n",connectfd);
   pthread_exit(NULL);
   
}


int main()
{  
   pthread_t tid;
   //int i;
   int listenfd,connectfd[MAX_THREAD_NUM];
   struct sockaddr_in server;                   // for Server(local)
   struct sockaddr_in client;                   // for Client(remote)
   int sin_size;                                // for sockaddr_in client
   int recvlen,sendlen;                         // recv/send data length
   //unsigned     char *p = (unsigned char *)&auth_req_block;
        int package_id;                         // App Data Package ID
        int i = 0;
   //(void) signal(SIGINT,closeSocket);
   // setAUTH_BACK_BLOCK();
//********* Create Socket: IPv4,TCP **************************
   if((listenfd = socket(AF_INET,SOCK_STREAM,0)) == -1)
   {
      perror("Create TCP Socket ERROR.");
      return 0;
   }
   printf("==> Create TCP Socket Success, fd is %d\n",listenfd);
        int on = 1;
//      setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on) );
   //********* Init Server sockaddr_in struct *******************
   bzero(&server,sizeof(server));               // 0
   server.sin_family = AF_INET;                 // IPv4
   server.sin_port = htons(TCP_PORT);
   server.sin_addr.s_addr = htonl(INADDR_ANY);  // Local IP
   //********* Init Bind TCP Socket *****************************
   if(bind(listenfd,(struct sockaddr *)&server,sizeof(struct sockaddr_in)) == -1)
   {
      perror("Bind TCP Socket ERROR.");
      return 0;
   }
   printf("==> Bind TCP Socket Success.\n");
   //********* Listen TCP Socket ********************************
   if(listen(listenfd,BACKLOG) == -1)
   {
      perror("Listen TCP Socket ERROR.");
      return 0;
   }
   printf("==> Listen TCP Socket Success.\n");

   //********* TCP Socket Trans *********************************
   for(i=0;i<MAX_THREAD_NUM;i++)
   {
      //********* TCP Socket Accept *****************************
      printf("==> Waiting for Connection...\n");
      sin_size = sizeof(struct sockaddr_in);
      if((connectfd[i] = accept(listenfd,(struct sockaddr *)&client,
                &sin_size)) == -1)
      {
        perror("Accept TCP Socket ERROR.");
        return 0;
      }
      printf("==> Accept OK...\n");
      printf("==>   Client IP is %s...\n",inet_ntoa(client.sin_addr));
                                        // print client IP
      printf("==>   Client Socket Port is %d\n",client.sin_port);
                                        // print client Port
      if(pthread_create(&tid,NULL,thread_socket,connectfd+i))
      {
         printf("create thread error ...\n");
         continue;
      }
      else
         printf("create thread OK ...\n");
   }
   close(listenfd);
   return 0;
}


