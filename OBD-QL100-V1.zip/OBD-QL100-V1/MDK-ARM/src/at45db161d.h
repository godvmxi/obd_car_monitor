#include "sysdef.h"
#ifndef	 SPI45DB161D_H_H
#define	 SPI45DB161D_H_H
//io����
/*FLASH
		IO����
		RESET  	--->	PB13
		CS		--->	PA13
		CLK		--->	PB12
		SI		--->	PA14
		SO		--->	PA15

				FLASH
		FLASH_RST			PC7
		FLASH_CS			PC6
		FLASH_SCK		  	PC8
		FLASH_SI		  	PC9
		FLASH_SO		  	PA8
*/
//
#define SPI_RESET_0			GPIO_WriteBit(GPIOC,GPIO_Pin_7,Bit_RESET)
#define SPI_RESET_1			GPIO_WriteBit(GPIOC,GPIO_Pin_7,Bit_SET)

#define SPI_CS_0			GPIO_WriteBit(GPIOC,GPIO_Pin_6,Bit_RESET)
#define SPI_CS_1			GPIO_WriteBit(GPIOC,GPIO_Pin_6,Bit_SET)

#define SPI_CLK_0			GPIO_WriteBit(GPIOC,GPIO_Pin_8,Bit_RESET)	
#define SPI_CLK_1   		GPIO_WriteBit(GPIOC,GPIO_Pin_8,Bit_SET)

#define SPI_SI_0			GPIO_WriteBit(GPIOC,GPIO_Pin_9,Bit_RESET)
#define SPI_SI_1			GPIO_WriteBit(GPIOC,GPIO_Pin_9,Bit_SET)

#define SPI_SO_STATE		GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)
#define SPI_NOP	spiNop(100)

//ָ���ֶ���
#define 	TRUE 														1
#define 	FALSE 														0


#define 	Write_Buffer1 												0x84//дBuffer1
#define 	Write_Buffer2 												0x87//дBuffer2

#define		Read_Buffer1												0xd4
#define		Read_Buffer2												0xd6
#define 	Status_Register_Read 										0xd7//��ȡflash״̬�Ĵ���
#define		Continuous_Array_Read 										0xe8//�����������ȡ
#define		Main_Memory_Page_Read										0xD2

#define 	Buffer1_To_MainMemory_PageProgram_WithBuilt_inErase			0x83//��Ԥ������д��Buffer1,��д��ָ��ҳ
#define 	Buffer2_To_MainMemory_PageProgram_WithBuilt_inErase 		0x86//��Ԥ������д��Buffer2,��д��ָ��ҳ

#define 	Buffer1_To_MainMemory_PageProgram_WithoutBuilt_inErase 		0x88//����Ԥ������д��Buffer1,��д��ָ��ҳ
#define 	Buffer2_To_MainMemory_PageProgram_WithoutBuilt_inErase 		0x89//����Ԥ������д��Buffer2,��д��ָ��ҳ

#define 	Page_Erase													0x81
#define 	Block_Erase													0x50

#define 	Main_Memory_Page_Program_Through_Buffer1					0x82
#define 	Main_Memory_Page_Program_Through_Buffer2					0x85

#define		Main_Memory_Page_To_Buffer1_Transfer						0x53
#define		Main_Memory_Page_To_Buffer2_Transfer						0x55

#define		Main_Memory_Page_To_Buffer1_Compare							0x60
#define		Main_Memory_Page_To_Buffer2_Compare							0x61

#define		Auto_Page_Rewrite_With_Buffer1								0x58
#define		Auto_Page_Rewrite_With_Buffer2								0x59





//
void 	initAT45DB041B(void);
void	spiNop(int delay);
u8		AT45DB041B_StatusRegisterRead(void);
void 	SPI_HostWriteByte(u8 dat);
u8   	SPI_HostReadByte(void);

u8		AT45DB041B_StatusRegisterRead(void);
void 	AT45DB041B_ContinuousArrayRead(u16 PA, u16 BFA, unsigned char *pHeader, u16 len);
void 	AT45DB041B_BufferRead(u8 buffer, u16 BFA, u8 *pHeader, u16 len);
void 	AT45DB041B_MainMemoryPageRead(u16 PA, u16 BFA, unsigned char *pHeader, u16 len);

void 	AT45DB041B_BufferToMainMemoryPageProgramWithBuilt_inErase(u8 buffer, u16 PA, u16 BFA, u8 *pHeader, u16 len);
void 	AT45DB041B_BufferToMainMemoryPageProgramWithoutBuilt_inErase(u8 buffer, u16 PA, u16 BFA, u8 *pHeader, u16 len);

void 	AT45DB041B_PageErase(u16 PA);
void 	AT45DB041B_BlockErase(u16 BLKA);

void 	AT45DB041B_MainMemoryPageToBufferTransfer(u8 buffer, u16 PA);
u8 		AT45DB041B_MainMemoryPageToBufferCompare(u8 buffer, u16 PA);

void 	AT45DB041B_MainMemoryPageProgramThroughBuffer(u8 buffer, u8 PA, u8 BFA, u8 *pHeader, u8 len);
void 	AT45DB041B_AutoPageRewrite(u8 buffer, u8 PA);
void showBuffer(u8 *pointer,int length);
void	flashTest(void);










#endif
